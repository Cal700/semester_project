#include <iostream>
#include <string>
#include <vector>
#include <cstdlib> // Include this header for C++98 compatibility

using namespace std;

struct User {
    string name;
    string phoneNumber;
    int balance;
    int pin;
    vector<string> transactionHistory;
};

void registerUser(vector<User>& users) {
    User newUser;
    cout << "Enter your name: ";
    cin.ignore();
    getline(cin, newUser.name);
    cout << "Enter your phone number: ";
    cin >> newUser.phoneNumber;
    cout << "Set your initial balance: ";
    cin >> newUser.balance;
    cout << "Set your PIN: ";
    cin >> newUser.pin;
    users.push_back(newUser);
    cout << "Registration successful.\n";
}

int findUserIndex(vector<User>& users, const string& phoneNumber) {
    for (int i = 0; i < users.size(); ++i) {
        if (users[i].phoneNumber == phoneNumber) {
            return i;
        }
    }
    return -1;
}

int loginUser(vector<User>& users) {
    string phoneNumber;
    int pin;
    cout << "Enter your phone number: ";
    cin >> phoneNumber;
    int userIndex = findUserIndex(users, phoneNumber);
    if (userIndex != -1) {
        cout << "Enter your PIN: ";
        cin >> pin;
        if (users[userIndex].pin == pin) {
            return userIndex;
        } else {
            cout << "Incorrect PIN.\n";
        }
    } else {
        cout << "User not found.\n";
    }
    return -1;
}

void checkBalance(const User& user) {
    cout << "Your balance: " << user.balance << "\n";
}

void transferMoney(User& sender, User& recipient) {
    int amount;
    cout << "Enter the amount to transfer: ";
    cin >> amount;

    if (amount <= sender.balance) {
        sender.balance -= amount;
        recipient.balance += amount;

        string senderTransaction = "Sent $" + to_string(amount) + " to " + recipient.name;
        string recipientTransaction = "Received $" + to_string(amount) + " from " + sender.name;

        sender.transactionHistory.push_back(senderTransaction);
        recipient.transactionHistory.push_back(recipientTransaction);

        cout << "Transfer successful.\n";
    } else {
        cout << "Insufficient balance. Transfer failed.\n";
    }
}

void purchaseAirtime(User& user) {
    int amount;
    cout << "Enter the amount of airtime to purchase: ";
    cin >> amount;

    if (amount <= user.balance) {
        user.balance -= amount;

        string transaction = "Purchased airtime of $" + to_string(amount);
        user.transactionHistory.push_back(transaction);

        cout << "Airtime purchase successful.\n";
    } else {
        cout << "Insufficient balance. Airtime purchase failed.\n";
    }
}

void viewTransactionHistory(const User& user) {
    cout << "Transaction History:\n";
    const vector<string>& history = user.transactionHistory;

    if (history.empty()) {
        cout << "No transactions found.\n";
    } else {
        for (const string& transaction : history) {
            cout << transaction << "\n";
        }
    }
}

void changePIN(User& user) {
    int currentPIN, newPIN;
    cout << "Enter your current PIN: ";
    cin >> currentPIN;

    if (currentPIN == user.pin) {
        cout << "Enter your new PIN: ";
        cin >> newPIN;
        user.pin = newPIN;
        cout << "PIN changed successfully.\n";
    } else {
        cout << "Incorrect current PIN. PIN change failed.\n";
    }
}

int main() {
    vector<User> users;
    int loggedInUserIndex = -1;

    while (true) {
        cout << "WELCOME TO VODAFONE CASH MINI\n";
        cout << "1. Register\n";
        cout << "2. Login\n";
        cout << "3. Exit\n";
        int choice;
        cin >> choice;

        switch (choice) {
            case 1:
                registerUser(users);
                break;
            case 2:
                loggedInUserIndex = loginUser(users);
                if (loggedInUserIndex != -1) {
                    cout << "Login successful.\n";
                }
                break;
            case 3:
                cout << "Exiting...\n";
                return 0;
            default:
                cout << "Invalid choice.\n";
                break;
        }

        while (loggedInUserIndex != -1) {
            cout << "\nUser Menu\n";
            cout << "1. Money Transfer\n";
            cout << "2. Check Balance\n";
            cout << "3. Airtime Purchase\n";
            cout << "4. Transaction History\n";
            cout << "5. Change Pin\n";
            cout << "6. Logout\n";
            int userChoice;
            cin >> userChoice;

            switch (userChoice) {
                case 1: {
                    string recipientPhoneNumber;
                    cout << "Enter recipient's phone number: ";
                    cin >> recipientPhoneNumber;

                    int recipientIndex = findUserIndex(users, recipientPhoneNumber);
                    if (recipientIndex != -1) {
                        transferMoney(users[loggedInUserIndex], users[recipientIndex]);
                    } else {
                        cout << "Recipient not found.\n";
                    }
                }
                break;
                case 2:
                    checkBalance(users[loggedInUserIndex]);
                    break;
                case 3:
                    purchaseAirtime(users[loggedInUserIndex]);
                    break;
                case 4:
                    viewTransactionHistory(users[loggedInUserIndex]);
                    break;
                case 5:
                    changePIN(users[loggedInUserIndex]);
                    break;
                case 6:
                    cout << "Logging out...\n";
                    loggedInUserIndex = -1;
                    break;
                default:
                    cout << "Invalid choice.\n";
                    break;
            }
        }
    }

    return 0;
}

